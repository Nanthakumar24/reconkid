"""
db.py
-----
Minimal SQLite persistence layer for scan history. Deliberately plain
sqlite3 (no ORM) to keep the project easy to read and run anywhere.
"""

import sqlite3
from datetime import datetime, timezone


def get_connection(db_path):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(db_path):
    conn = get_connection(db_path)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            target TEXT NOT NULL,
            scan_date TEXT NOT NULL,
            risk_score INTEGER NOT NULL,
            rating TEXT NOT NULL,
            status TEXT NOT NULL,
            report_path TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


def insert_scan(db_path, target, risk_score, rating, status, report_path):
    conn = get_connection(db_path)
    cur = conn.execute(
        "INSERT INTO scans (target, scan_date, risk_score, rating, status, report_path) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (target, datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
         risk_score, rating, status, report_path),
    )
    conn.commit()
    scan_id = cur.lastrowid
    conn.close()
    return scan_id


def get_all_scans(db_path, search=None):
    conn = get_connection(db_path)
    if search:
        rows = conn.execute(
            "SELECT * FROM scans WHERE target LIKE ? ORDER BY id DESC",
            (f"%{search}%",),
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM scans ORDER BY id DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_scan(db_path, scan_id):
    conn = get_connection(db_path)
    row = conn.execute("SELECT * FROM scans WHERE id = ?", (scan_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def delete_scan(db_path, scan_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM scans WHERE id = ?", (scan_id,))
    conn.commit()
    conn.close()


def get_stats(db_path):
    conn = get_connection(db_path)
    total = conn.execute("SELECT COUNT(*) AS c FROM scans").fetchone()["c"]
    recent = conn.execute("SELECT * FROM scans ORDER BY id DESC LIMIT 1").fetchone()
    avg_score_row = conn.execute("SELECT AVG(risk_score) AS avg_score FROM scans").fetchone()
    conn.close()
    avg_score = round(avg_score_row["avg_score"]) if avg_score_row and avg_score_row["avg_score"] is not None else None
    return {
        "total_scans": total,
        "recent_scan": dict(recent) if recent else None,
        "avg_security_score": avg_score,
    }
