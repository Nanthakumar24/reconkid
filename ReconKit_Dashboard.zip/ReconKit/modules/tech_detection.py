"""
modules/tech_detection.py
---------------------------
Lightweight technology fingerprinting from a single HTTP(S) request.

Detects web server, CMS, framework, programming language, CDN, and a
handful of common JavaScript libraries by inspecting response headers
and the first chunk of the page body. This is a heuristic pass, not an
exhaustive fingerprinting engine - deliberately kept passive and fast.
"""

import re

import requests

BODY_SIGNATURES = [
    ("WordPress", "cms", ["wp-content", "wp-json", "wp-includes"]),
    ("Shopify", "cms", ["cdn.shopify.com", "shopify.com/s/"]),
    ("Drupal", "cms", ["drupal.js", "sites/default/files"]),
    ("Joomla", "cms", ["/media/jui/", "joomla"]),
    ("Wix", "cms", ["wix.com", "wixstatic.com"]),
    ("Squarespace", "cms", ["squarespace.com", "static1.squarespace"]),
    ("Next.js", "framework", ["__next_data__", "/_next/"]),
    ("Nuxt.js", "framework", ["__nuxt__", "/_nuxt/"]),
    ("React", "js_library", ["react-dom", "data-reactroot"]),
    ("Vue.js", "js_library", ["__vue__", "v-cloak"]),
    ("Angular", "js_library", ["ng-version", "ng-app"]),
    ("jQuery", "js_library", ["jquery.min.js", "jquery.js"]),
    ("Bootstrap", "js_library", ["bootstrap.min.css", "bootstrap.min.js"]),
    ("Tailwind CSS", "js_library", ["tailwind"]),
]

LANGUAGE_HINTS = [
    (re.compile(r"\.php(\?|$)", re.I), "PHP"),
    (re.compile(r"\.aspx?(\?|$)", re.I), "ASP.NET"),
    (re.compile(r"\.jsp(\?|$)", re.I), "Java (JSP)"),
    (re.compile(r"x-powered-by:\s*express", re.I), "Node.js (Express)"),
]


def _detect_cdn(headers, server_header):
    server_lower = (server_header or "").lower()
    if "cf-ray" in headers or "cloudflare" in server_lower:
        return "Cloudflare"
    if "x-amz-cf-id" in headers:
        return "Amazon CloudFront"
    if "x-akamai" in "".join(headers.keys()).lower():
        return "Akamai"
    if "x-fastly-request-id" in headers or "fastly" in server_lower:
        return "Fastly"
    if "x-vercel-id" in headers:
        return "Vercel"
    return None


def detect_tech(host, timeout=6):
    """
    Returns a dict like:
        {
            "server": "nginx", "cms": "WordPress", "framework": None,
            "language": "PHP", "cdn": "Cloudflare",
            "js_libraries": ["jQuery", "Bootstrap"],
            "headers_seen": {...}, "error": None
        }
    """
    result = {
        "server": None, "cms": None, "framework": None, "language": None,
        "cdn": None, "js_libraries": [], "headers_seen": {}, "error": None,
    }

    body = ""
    headers = {}
    reached = False
    for scheme in ("https", "http"):
        try:
            resp = requests.get(
                f"{scheme}://{host}", timeout=timeout, allow_redirects=True,
                headers={"User-Agent": "ReconKit-Dashboard/1.0 (+passive recon)"},
            )
            headers = resp.headers
            body = resp.text[:30000].lower()
            reached = True
            break
        except Exception as exc:
            result["error"] = str(exc)
            continue

    if not reached:
        return result

    result["error"] = None
    server_header = headers.get("Server")
    powered_by = headers.get("X-Powered-By")

    if server_header:
        result["server"] = server_header
    if powered_by:
        result["framework"] = powered_by

    result["cdn"] = _detect_cdn(headers, server_header)

    js_libs = []
    for name, kind, needles in BODY_SIGNATURES:
        if any(n in body for n in needles):
            if kind == "cms" and not result["cms"]:
                result["cms"] = name
            elif kind == "framework" and not result["framework"]:
                result["framework"] = name
            elif kind == "js_library":
                js_libs.append(name)
    result["js_libraries"] = js_libs

    for pattern, lang in LANGUAGE_HINTS:
        if pattern.search(body) or pattern.search(str(headers)):
            result["language"] = lang
            break

    result["headers_seen"] = dict(headers)
    return result
