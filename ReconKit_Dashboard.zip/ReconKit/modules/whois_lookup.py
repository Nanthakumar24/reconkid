"""
modules/whois_lookup.py
------------------------
Passive WHOIS lookup.

Retrieves registrar, domain age, creation/expiry/updated dates, name
servers, organization, and country for a target domain.

Tries the classic WHOIS protocol (TCP/43) via python-whois first, and
falls back to RDAP (the modern HTTPS-based WHOIS replacement) if that
fails or is blocked - some sandboxed/corporate networks only allow
HTTPS egress.
"""

from datetime import datetime, timezone

import requests

try:
    import whois as whois_lib
    HAVE_WHOIS = True
except ImportError:
    HAVE_WHOIS = False


def _fmt_date(val):
    """WHOIS libraries sometimes return a list of dates or datetime objects."""
    if isinstance(val, list):
        val = val[0] if val else None
    if isinstance(val, datetime):
        return val.strftime("%Y-%m-%d")
    return val


def _domain_age_days(created_str):
    if not created_str:
        return None
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"):
        try:
            created = datetime.strptime(created_str[:19], fmt)
            return (datetime.utcnow() - created).days
        except Exception:
            continue
    return None


def _via_whois_protocol(domain):
    if not HAVE_WHOIS:
        return {}, "python-whois package not installed"
    try:
        w = whois_lib.whois(domain)
    except Exception as exc:
        return {}, f"WHOIS (port 43) failed: {exc}"

    out = {}
    registrar = _fmt_date(w.get("registrar"))
    created = _fmt_date(w.get("creation_date"))
    expires = _fmt_date(w.get("expiration_date"))
    updated = _fmt_date(w.get("updated_date"))
    name_servers = w.get("name_servers")
    org = w.get("org") or w.get("registrant_org") or w.get("organization")
    country = w.get("country")

    if registrar:
        out["registrar"] = registrar
    if created:
        out["creation_date"] = created
    if expires:
        out["expiry_date"] = expires
    if updated:
        out["updated_date"] = updated
    if name_servers:
        if isinstance(name_servers, (list, set)):
            out["name_servers"] = sorted({str(n).lower() for n in name_servers})
        else:
            out["name_servers"] = [str(name_servers).lower()]
    if org:
        out["organization"] = org
    if country:
        out["country"] = country if isinstance(country, str) else str(country)

    if not out:
        return {}, "WHOIS (port 43) returned no usable fields"
    return out, None


def _rdap_entity_name(entity):
    for arr in entity.get("vcardArray") or []:
        if isinstance(arr, list):
            for field in arr:
                if isinstance(field, list) and len(field) >= 4 and field[0] == "fn":
                    return field[3]
    return entity.get("handle")


def _via_rdap(domain, timeout=10):
    try:
        resp = requests.get(
            f"https://rdap.org/domain/{domain}",
            timeout=timeout,
            headers={"User-Agent": "Mozilla/5.0 (ReconKit-Dashboard/1.0)"},
        )
    except Exception as exc:
        return {}, f"RDAP lookup failed: {exc}"

    if resp.status_code == 404:
        return {}, "RDAP: domain not found"
    if resp.status_code != 200:
        return {}, f"RDAP returned HTTP {resp.status_code}"

    try:
        data = resp.json()
    except Exception as exc:
        return {}, f"RDAP returned unparsable response: {exc}"

    out = {}
    for event in data.get("events", []):
        action = (event.get("eventAction") or "").lower()
        date = (event.get("eventDate") or "")[:10]
        if action == "registration" and date:
            out["creation_date"] = date
        elif action == "expiration" and date:
            out["expiry_date"] = date
        elif action == "last changed" and date:
            out["updated_date"] = date

    for entity in data.get("entities", []):
        if "registrar" in (entity.get("roles") or []):
            name = _rdap_entity_name(entity)
            if name:
                out["registrar"] = name
            break

    nameservers = [ns.get("ldhName") for ns in data.get("nameservers", []) if ns.get("ldhName")]
    if nameservers:
        out["name_servers"] = sorted(n.lower() for n in nameservers)

    country = data.get("country")
    if country:
        out["country"] = country

    if not out:
        return {}, "RDAP returned no usable fields"
    return out, None


def lookup_whois(domain):
    """
    Look up WHOIS/RDAP data for `domain`.

    Returns a dict like:
        {
            "data": {"registrar": ..., "creation_date": ..., "domain_age_days": ..., ...},
            "error": None or "reason both lookups failed"
        }
    """
    out, err1 = _via_whois_protocol(domain)
    if not out:
        out, err2 = _via_rdap(domain)
    else:
        err2 = None

    if not out:
        errors = [e for e in (err1, err2) if e]
        return {"data": {}, "error": "; ".join(errors) if errors else "No WHOIS data available"}

    age = _domain_age_days(out.get("creation_date"))
    if age is not None:
        out["domain_age_days"] = age

    return {"data": out, "error": None}
