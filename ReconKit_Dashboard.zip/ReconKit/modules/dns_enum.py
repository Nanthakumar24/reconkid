"""
modules/dns_enum.py
--------------------
Passive DNS enumeration.

Retrieves A, AAAA, MX, NS, TXT, SOA, and CNAME records for a target domain.
Uses dnspython when available for a full, accurate lookup, and falls back
to Python's built-in `socket` module for basic A/AAAA resolution if
dnspython isn't installed or a lookup fails. This is purely passive - it
only queries public DNS, never touches the target host directly.
"""

import socket

try:
    import dns.resolver
    HAVE_DNSPYTHON = True
except ImportError:
    HAVE_DNSPYTHON = False

RECORD_TYPES = ["A", "AAAA", "MX", "NS", "TXT", "SOA", "CNAME"]


def _socket_fallback(domain):
    """Best-effort A/AAAA lookup using only the standard library."""
    records = {}
    try:
        ips = sorted({info[4][0] for info in socket.getaddrinfo(domain, None, socket.AF_INET)})
        if ips:
            records["A"] = ips
    except Exception:
        pass
    try:
        ips6 = sorted({info[4][0] for info in socket.getaddrinfo(domain, None, socket.AF_INET6)})
        if ips6:
            records["AAAA"] = ips6
    except Exception:
        pass
    return records


def enumerate_dns(domain, timeout=4):
    """
    Query common DNS record types for `domain`.

    Returns a dict like:
        {
            "records": {"A": [...], "MX": [...], ...},
            "errors": ["MX lookup failed: ...", ...]
        }
    """
    records = {}
    errors = []

    if HAVE_DNSPYTHON:
        resolver = dns.resolver.Resolver()
        resolver.timeout = timeout
        resolver.lifetime = timeout

        for rtype in RECORD_TYPES:
            try:
                answer = resolver.resolve(domain, rtype, lifetime=timeout)
                values = [str(rdata).strip('"') for rdata in answer]
                if values:
                    records[rtype] = values
            except dns.resolver.NoAnswer:
                continue
            except dns.resolver.NXDOMAIN:
                errors.append(f"{domain} does not exist (NXDOMAIN)")
                break
            except Exception as exc:
                errors.append(f"{rtype} lookup failed: {exc}")
                continue
    else:
        errors.append("dnspython not installed - falling back to socket resolution only")

    # Always make sure we at least have A/AAAA, even if dnspython couldn't
    # reach its configured resolver (common in sandboxed networks).
    if "A" not in records or "AAAA" not in records:
        fallback = _socket_fallback(domain)
        for key, val in fallback.items():
            records.setdefault(key, val)

    return {"records": records, "errors": errors}
