"""
modules/port_scanner.py
------------------------
Lightweight TCP connect-scan against a curated list of common ports.

This performs a plain `socket.create_connection` attempt on each port -
the same "is anything listening" check a basic `nmap -Pn` connect scan
does. It does NOT attempt banner grabbing beyond what a raw TCP connect
reveals, exploitation, or any brute-forcing. Purely observational.
"""

import socket
import time
from concurrent.futures import ThreadPoolExecutor, as_completed


def _scan_single_port(host, port, timeout):
    try:
        start = time.time()
        with socket.create_connection((host, port), timeout=timeout):
            elapsed_ms = round((time.time() - start) * 1000, 1)
            return port, "open", elapsed_ms
    except (socket.timeout, TimeoutError):
        return port, "filtered", None
    except ConnectionRefusedError:
        return port, "closed", None
    except Exception:
        return port, "closed", None


def scan_ports(host, common_ports, timeout=1.5, max_workers=20):
    """
    Scan `host` across the (port, service, risk) tuples in `common_ports`.

    Returns a dict like:
        {
            "ports": [
                {"port": 22, "service": "SSH", "status": "open",
                 "risk": "low", "latency_ms": 12.3},
                ...
            ],
            "open_count": 3,
        }
    """
    results_by_port = {}

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {
            pool.submit(_scan_single_port, host, port, timeout): (port, service, risk)
            for port, service, risk in common_ports
        }
        for fut in as_completed(futures):
            port, status, latency = fut.result()
            results_by_port[port] = (status, latency)

    ports = []
    for port, service, risk in common_ports:
        status, latency = results_by_port.get(port, ("unknown", None))
        ports.append({
            "port": port,
            "service": service,
            "status": status,
            # Risk only really matters if the port is actually open/reachable
            "risk": risk if status == "open" else "none",
            "latency_ms": latency,
        })

    # Sort: open first, then filtered, then closed - so what matters most
    # surfaces at the top of the results table.
    order = {"open": 0, "filtered": 1, "unknown": 2, "closed": 3}
    ports.sort(key=lambda p: order.get(p["status"], 4))

    open_count = sum(1 for p in ports if p["status"] == "open")
    return {"ports": ports, "open_count": open_count}
