"""
modules package
----------------
Each recon capability lives in its own module (dns_enum, whois_lookup,
port_scanner, ssl_checker, tech_detection, security_headers) and
report_generator combines all of their output into one JSON report.

`run_full_scan` orchestrates a full pass across every module for a
single target and is the single entry point app.py calls.
"""

import re
import time

from . import dns_enum, whois_lookup, port_scanner, ssl_checker, tech_detection, security_headers, report_generator

TARGET_RE = re.compile(
    r"^(?=.{1,253}$)(?!-)[A-Za-z0-9-]{1,63}(?<!-)(\.[A-Za-z0-9-]{1,63}(?<!-))*$"
)


def clean_target(raw):
    """Strip scheme/path/whitespace and validate the input looks like a domain or IP."""
    if not raw:
        return None
    value = raw.strip().lower()
    value = re.sub(r"^https?://", "", value)
    value = value.split("/")[0]
    value = value.split(":")[0]
    value = value.rstrip(".")
    if not value or not TARGET_RE.match(value):
        return None
    return value


def run_full_scan(target, config, progress_cb=None):
    """
    Run every recon module against `target` in sequence and combine the
    results into one report via report_generator.

    `progress_cb(step_name, pct)` is called after each module completes,
    so a caller can stream progress to the UI if desired.
    """
    def emit(step, pct):
        if progress_cb:
            progress_cb(step, pct)

    start = time.time()

    emit("Resolving DNS records", 10)
    dns_result = dns_enum.enumerate_dns(target, timeout=config.DNS_TIMEOUT)

    emit("Querying WHOIS / RDAP", 25)
    whois_result = whois_lookup.lookup_whois(target)

    emit("Scanning common TCP ports", 50)
    port_result = port_scanner.scan_ports(
        target, config.COMMON_PORTS,
        timeout=config.CONNECT_TIMEOUT, max_workers=config.PORT_SCAN_WORKERS,
    )

    emit("Inspecting SSL/TLS certificate", 65)
    ssl_result = ssl_checker.check_ssl(target)

    emit("Fingerprinting technology stack", 80)
    tech_result = tech_detection.detect_tech(target, timeout=config.HTTP_TIMEOUT)

    emit("Checking security headers", 90)
    headers_result = security_headers.check_security_headers(
        target, config.REQUIRED_SECURITY_HEADERS, timeout=config.HTTP_TIMEOUT
    )

    duration = round(time.time() - start, 1)

    emit("Compiling report", 97)
    report, filepath = report_generator.generate_report(
        target, dns_result, whois_result, port_result, ssl_result,
        tech_result, headers_result, duration, config.REPORTS_DIR,
    )

    emit("Done", 100)
    return report, filepath
