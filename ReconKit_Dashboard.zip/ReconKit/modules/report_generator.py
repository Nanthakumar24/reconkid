"""
modules/report_generator.py
------------------------------
Combines the output of every recon module into one structured report,
computes an overall risk score / security rating, and writes the report
to disk as JSON.
"""

import json
import os
from datetime import datetime, timezone

RISK_WEIGHTS = {"critical": 25, "high": 15, "medium": 8, "low": 3, "none": 0}


def _score_open_ports(ports):
    """Deduct points for each open port, weighted by its risk level."""
    deduction = 0
    dangerous = []
    for p in ports:
        if p["status"] == "open" and p["risk"] != "none":
            deduction += RISK_WEIGHTS.get(p["risk"], 5)
            if p["risk"] in ("critical", "high"):
                dangerous.append(p)
    return deduction, dangerous


def _score_ssl(ssl_info):
    if not ssl_info.get("available"):
        return 15, "HTTPS/TLS is not reachable on port 443."
    if ssl_info.get("expired"):
        return 25, "TLS certificate has expired."
    remaining = ssl_info.get("remaining_days")
    if remaining is not None and remaining < 15:
        return 10, f"TLS certificate expires soon ({remaining} days remaining)."
    return 0, None


def _score_headers(headers_result):
    missing = headers_result.get("missing", [])
    # Each missing header costs a few points, capped so this alone
    # can't zero out the score.
    return min(len(missing) * 4, 24), missing


def _rating_from_score(score):
    if score >= 90:
        return "A", "Excellent"
    if score >= 75:
        return "B", "Good"
    if score >= 60:
        return "C", "Fair"
    if score >= 40:
        return "D", "Poor"
    return "F", "Critical"


def _build_recommendations(dangerous_ports, ssl_issue, missing_headers, tech):
    recs = []
    for p in dangerous_ports:
        recs.append(
            f"Restrict or firewall port {p['port']} ({p['service']}) - it is open and carries "
            f"{p['risk']} risk if internet-facing without a specific need."
        )
    if ssl_issue:
        recs.append(f"Resolve TLS issue: {ssl_issue}")
    for header in missing_headers:
        recs.append(f"Add the '{header}' response header to harden the application.")
    server = tech.get("server") if tech else None
    if server and any(ch.isdigit() for ch in server):
        recs.append(
            f"Suppress or generalize the 'Server' header ('{server}') to avoid disclosing "
            "exact software versions to attackers."
        )
    if not recs:
        recs.append("No major issues detected - maintain current security posture and re-scan periodically.")
    return recs


def generate_report(target, dns_result, whois_result, port_result, ssl_result,
                     tech_result, headers_result, scan_duration_sec, reports_dir):
    """
    Combine all module outputs into one structured report dict, compute a
    risk score (0-100, higher is better) and letter rating, and persist
    the report as JSON under `reports_dir`.

    Returns (report_dict, report_filepath).
    """
    port_deduction, dangerous_ports = _score_open_ports(port_result.get("ports", []))
    ssl_deduction, ssl_issue = _score_ssl(ssl_result)
    header_deduction, missing_headers = _score_headers(headers_result)

    score = 100 - port_deduction - ssl_deduction - header_deduction
    score = max(0, min(100, score))
    rating, rating_label = _rating_from_score(score)

    recommendations = _build_recommendations(dangerous_ports, ssl_issue, missing_headers, tech_result)

    server_header = (tech_result or {}).get("server")
    tech_risk = None
    if server_header and any(ch.isdigit() for ch in server_header):
        tech_risk = f"Server header discloses version info: {server_header}"

    timestamp = datetime.now(timezone.utc)

    report = {
        "target": target,
        "scan_date": timestamp.strftime("%Y-%m-%d %H:%M:%S UTC"),
        "scan_duration_sec": scan_duration_sec,
        "modules": {
            "dns": dns_result,
            "whois": whois_result,
            "ports": port_result,
            "ssl": ssl_result,
            "technology": tech_result,
            "security_headers": headers_result,
        },
        "vulnerability_summary": {
            "risk_score": score,
            "security_rating": rating,
            "rating_label": rating_label,
            "missing_headers": missing_headers,
            "dangerous_open_ports": dangerous_ports,
            "weak_ssl": ssl_issue,
            "tech_risk": tech_risk,
            "recommendations": recommendations,
        },
    }

    os.makedirs(reports_dir, exist_ok=True)
    safe_target = "".join(c if c.isalnum() or c in "-._" else "_" for c in target)
    filename = f"{safe_target}_{timestamp.strftime('%Y%m%d%H%M%S')}.json"
    filepath = os.path.join(reports_dir, filename)

    with open(filepath, "w") as f:
        json.dump(report, f, indent=2, default=str)

    return report, filepath
