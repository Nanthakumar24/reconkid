"""
modules/security_headers.py
------------------------------
Checks a target's HTTP response for the presence of six important
security headers and reports which ones are missing.
"""

import requests


def check_security_headers(host, required_headers, timeout=6):
    """
    Returns a dict like:
        {
            "checked": True,
            "present": {"Content-Security-Policy": "default-src 'self'", ...},
            "missing": ["X-Frame-Options", "Permissions-Policy"],
            "score": 4,          # out of len(required_headers)
            "error": None,
        }
    """
    present = {}
    missing = []

    reached = False
    last_error = None
    for scheme in ("https", "http"):
        try:
            resp = requests.get(
                f"{scheme}://{host}", timeout=timeout, allow_redirects=True,
                headers={"User-Agent": "ReconKit-Dashboard/1.0 (+passive recon)"},
            )
            headers = resp.headers
            reached = True
            break
        except Exception as exc:
            last_error = str(exc)
            continue

    if not reached:
        return {
            "checked": False, "present": {}, "missing": required_headers,
            "score": 0, "error": last_error or "Host unreachable",
        }

    for header_name in required_headers:
        value = headers.get(header_name)
        if value:
            present[header_name] = value
        else:
            missing.append(header_name)

    return {
        "checked": True,
        "present": present,
        "missing": missing,
        "score": len(present),
        "error": None,
    }
