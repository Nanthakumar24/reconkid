"""
modules/ssl_checker.py
------------------------
Inspects the TLS certificate presented on port 443.

Retrieves issuer, subject, expiry, TLS protocol version, serial number,
and remaining days until expiry. Read-only - opens a standard TLS
handshake, exactly like a browser does, and reads the certificate that
comes back.
"""

import socket
import ssl
from datetime import datetime, timezone


def check_ssl(host, port=443, timeout=5):
    """
    Returns a dict like:
        {
            "available": True,
            "issuer": "...", "subject": "...", "valid_from": "...",
            "valid_to": "...", "version": "TLSv1.3", "serial_number": "...",
            "remaining_days": 42, "expired": False,
        }
    or {"available": False, "error": "..."} if the handshake failed.
    """
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, port), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                cert = ssock.getpeercert()
                version = ssock.version()
    except Exception as exc:
        return {"available": False, "error": str(exc)}

    issuer = dict(x[0] for x in cert.get("issuer", []))
    subject = dict(x[0] for x in cert.get("subject", []))
    not_after = cert.get("notAfter")
    not_before = cert.get("notBefore")
    serial_number = cert.get("serialNumber", "Unknown")

    remaining_days = None
    expired = False
    if not_after:
        try:
            expiry_dt = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
            remaining_days = (expiry_dt - datetime.now(timezone.utc)).days
            expired = remaining_days < 0
        except Exception:
            pass

    return {
        "available": True,
        "issuer": issuer.get("organizationName") or issuer.get("commonName", "Unknown"),
        "subject": subject.get("commonName", host),
        "valid_from": not_before,
        "valid_to": not_after,
        "version": version,
        "serial_number": serial_number,
        "remaining_days": remaining_days,
        "expired": expired,
    }
