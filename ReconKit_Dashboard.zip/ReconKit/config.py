"""
config.py
---------
Central configuration for the ReconKit Dashboard Flask app.
Keeping this in one place makes it easy to tweak timeouts, ports,
and storage locations without hunting through the codebase.
"""

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


class Config:
    # --- Flask core ---
    SECRET_KEY = os.environ.get("RECONKIT_SECRET_KEY", "reconkit-dev-secret-key-change-me")
    DEBUG = True

    # --- Storage ---
    INSTANCE_DIR = os.path.join(BASE_DIR, "instance")
    DATABASE_PATH = os.path.join(INSTANCE_DIR, "database.db")
    REPORTS_DIR = os.path.join(BASE_DIR, "reports")

    # --- Scan behaviour ---
    CONNECT_TIMEOUT = 1.5          # seconds, per-port TCP connect attempt
    HTTP_TIMEOUT = 6               # seconds, HTTP header/tech-detection requests
    DNS_TIMEOUT = 4                # seconds, per-record-type DNS lookups
    PORT_SCAN_WORKERS = 20         # thread pool size for concurrent port checks

    # Common TCP ports checked by the passive port scanner module.
    # (service name, risk level if found open)
    COMMON_PORTS = [
        (21, "FTP", "high"),
        (22, "SSH", "low"),
        (23, "Telnet", "critical"),
        (25, "SMTP", "medium"),
        (53, "DNS", "low"),
        (80, "HTTP", "low"),
        (110, "POP3", "medium"),
        (143, "IMAP", "medium"),
        (443, "HTTPS", "low"),
        (445, "SMB", "critical"),
        (993, "IMAPS", "low"),
        (995, "POP3S", "low"),
        (1433, "MSSQL", "high"),
        (3306, "MySQL", "high"),
        (3389, "RDP", "critical"),
        (5432, "PostgreSQL", "high"),
        (6379, "Redis", "high"),
        (8080, "HTTP-Alt", "medium"),
        (8443, "HTTPS-Alt", "medium"),
        (27017, "MongoDB", "high"),
    ]

    # Security headers the security_headers module checks for.
    REQUIRED_SECURITY_HEADERS = [
        "Content-Security-Policy",
        "Strict-Transport-Security",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
        "Permissions-Policy",
    ]
