"""
app.py
------
ReconKit Dashboard - Flask application entry point.

Wires up configuration, initializes the SQLite database, registers the
Blueprints, and exposes a couple of small template helpers (like risk
badge colors) used across pages.

Run with:
    pip install -r requirements.txt
    python app.py
Then open http://127.0.0.1:5000
"""

import os

from flask import Flask

from config import Config
import db as db_module
from blueprints.main import main_bp
from blueprints.api import api_bp

RISK_BADGE_CLASSES = {
    "critical": "badge-risk-critical",
    "high": "badge-risk-high",
    "medium": "badge-risk-medium",
    "low": "badge-risk-low",
    "none": "badge-risk-none",
}

RATING_CLASSES = {
    "A": "rating-a", "B": "rating-b", "C": "rating-c",
    "D": "rating-d", "F": "rating-f",
}


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    # Store the raw Config class too, since modules.run_full_scan wants
    # attribute access (COMMON_PORTS, timeouts, etc.) rather than a dict.
    app.config["APP_CONFIG"] = Config

    os.makedirs(Config.INSTANCE_DIR, exist_ok=True)
    os.makedirs(Config.REPORTS_DIR, exist_ok=True)
    db_module.init_db(Config.DATABASE_PATH)

    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp)

    @app.template_filter("risk_badge")
    def risk_badge(risk_level):
        return RISK_BADGE_CLASSES.get((risk_level or "none").lower(), "badge-risk-none")

    @app.template_filter("rating_class")
    def rating_class(rating):
        return RATING_CLASSES.get((rating or "F").upper(), "rating-f")

    @app.context_processor
    def inject_globals():
        return {"app_name": "ReconKit Dashboard", "app_version": "1.0.0"}

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
