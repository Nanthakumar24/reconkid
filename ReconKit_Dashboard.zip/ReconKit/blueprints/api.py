"""
blueprints/api.py
-------------------
JSON API used by the Scan page's JavaScript to kick off a scan and
receive back where to redirect once it's done. The actual scan runs
synchronously inside the request - modules are fast (a few seconds at
most) since everything is a lightweight, mostly-passive check.
"""

import os

from flask import Blueprint, current_app, jsonify, request

import db
import modules

api_bp = Blueprint("api", __name__, url_prefix="/api")


@api_bp.route("/scan", methods=["POST"])
def run_scan():
    payload = request.get_json(silent=True) or request.form
    raw_target = payload.get("target", "")

    target = modules.clean_target(raw_target)
    if not target:
        return jsonify({
            "ok": False,
            "error": f"'{raw_target}' doesn't look like a valid domain or IP address.",
        }), 400

    try:
        report, filepath = modules.run_full_scan(target, current_app.config["APP_CONFIG"])
    except Exception as exc:
        return jsonify({"ok": False, "error": f"Scan failed: {exc}"}), 500

    summary = report["vulnerability_summary"]
    scan_id = db.insert_scan(
        current_app.config["DATABASE_PATH"],
        target=target,
        risk_score=summary["risk_score"],
        rating=summary["security_rating"],
        status="completed",
        report_path=filepath,
    )

    return jsonify({
        "ok": True,
        "scan_id": scan_id,
        "target": target,
        "risk_score": summary["risk_score"],
        "rating": summary["security_rating"],
        "redirect_url": f"/results/{scan_id}",
    })
