"""
blueprints/main.py
--------------------
All user-facing page routes: Home, Scan, Results, Vulnerability Report,
Scan History, and About. Scan execution itself lives in blueprints/api.py
so this file stays focused on rendering pages.
"""

import json
import os

from flask import Blueprint, current_app, render_template, redirect, url_for, flash, request, send_file, abort

import db

main_bp = Blueprint("main", __name__)


def _load_report(report_path):
    if not report_path or not os.path.exists(report_path):
        return None
    with open(report_path, "r") as f:
        return json.load(f)


@main_bp.route("/")
def home():
    stats = db.get_stats(current_app.config["DATABASE_PATH"])
    recent_scans = db.get_all_scans(current_app.config["DATABASE_PATH"])[:5]
    return render_template("home.html", stats=stats, recent_scans=recent_scans)


@main_bp.route("/scan")
def scan_page():
    return render_template("scan.html")


@main_bp.route("/results/<int:scan_id>")
def results(scan_id):
    scan_row = db.get_scan(current_app.config["DATABASE_PATH"], scan_id)
    if not scan_row:
        flash("That scan no longer exists.", "error")
        return redirect(url_for("main.history"))

    report = _load_report(scan_row["report_path"])
    if not report:
        flash("The report file for that scan couldn't be found on disk.", "error")
        return redirect(url_for("main.history"))

    return render_template("results.html", scan=scan_row, report=report)


@main_bp.route("/vulnerability-report/<int:scan_id>")
def vulnerability_report(scan_id):
    scan_row = db.get_scan(current_app.config["DATABASE_PATH"], scan_id)
    if not scan_row:
        flash("That scan no longer exists.", "error")
        return redirect(url_for("main.history"))

    report = _load_report(scan_row["report_path"])
    if not report:
        flash("The report file for that scan couldn't be found on disk.", "error")
        return redirect(url_for("main.history"))

    return render_template("vulnerability_report.html", scan=scan_row, report=report)


@main_bp.route("/history")
def history():
    search = request.args.get("q", "").strip()
    scans = db.get_all_scans(current_app.config["DATABASE_PATH"], search=search or None)
    return render_template("history.html", scans=scans, search=search)


@main_bp.route("/history/delete/<int:scan_id>", methods=["POST"])
def delete_scan(scan_id):
    scan_row = db.get_scan(current_app.config["DATABASE_PATH"], scan_id)
    if scan_row:
        report_path = scan_row["report_path"]
        db.delete_scan(current_app.config["DATABASE_PATH"], scan_id)
        if report_path and os.path.exists(report_path):
            try:
                os.remove(report_path)
            except OSError:
                pass
        flash(f"Deleted scan of {scan_row['target']}.", "success")
    else:
        flash("That scan no longer exists.", "error")
    return redirect(url_for("main.history"))


@main_bp.route("/report/download/<int:scan_id>")
def download_report(scan_id):
    scan_row = db.get_scan(current_app.config["DATABASE_PATH"], scan_id)
    if not scan_row or not os.path.exists(scan_row["report_path"]):
        abort(404)
    return send_file(
        scan_row["report_path"],
        as_attachment=True,
        download_name=f"reconkit_report_{scan_row['target']}_{scan_id}.json",
        mimetype="application/json",
    )


@main_bp.route("/about")
def about():
    return render_template("about.html")
